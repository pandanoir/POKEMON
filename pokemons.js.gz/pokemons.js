var POKEMON=(function(){
	var poke=function(name){
		this.attack=pokemonValue[name].attack;
		this.defence=pokemonValue[name].defence;
		this.speed=pokemonValue[name].speed;
		this.hp=pokemonValue[name].hp;
		this.img=pokemonValue[name].img;
		this.name=name;
	}
	poke.fn=poke.prototype;
	return poke;
})();
var pokemonValue={
	"まさる":{attack:30,defence:30,speed:30,hp:30,img:new Image(),src:"masaru2.png"}
};
(function(){
	for(var key in pokemonValue){
		pokemonValue[key].img.src=pokemonValue[key].src;
	}
})()